# memhole

[![PyPI - Version](https://img.shields.io/pypi/v/memhole.svg)](https://pypi.org/project/memhole)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/memhole.svg)](https://pypi.org/project/memhole)

-----

**Table of Contents**

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install memhole
```

## License

`memhole` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
